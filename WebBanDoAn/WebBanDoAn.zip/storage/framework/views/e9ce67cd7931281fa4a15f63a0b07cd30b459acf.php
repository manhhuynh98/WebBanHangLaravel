<td><input disabled class="form-control form-control-plaintext" name="name" id="name-<?php echo e($user->id); ?>" type="text"
        value="<?php echo e($user->name); ?>"></td>
<td><input disabled class="form-control form-control-plaintext" name="email" id="email-<?php echo e($user->id); ?>" type="text"
        value="<?php echo e($user->email); ?>"></td>
<td><input disabled class="form-control form-control-plaintext" name="image" id="image-<?php echo e($user->id); ?>" type="text"
        value="<?php echo e($user->image); ?>"></td>
<td>
    <select class="form-control form-control-plaintext" name="role" id="role-<?php echo e($user->id); ?>" disabled>
        <?php if($user->role == 1): ?>
            <option value="1" selected>Admin</option>
            <option value="0">Thường</option>
        <?php else: ?>
            <option value="0" selected>Thường</option>
            <option value="1">Admin</option>
        <?php endif; ?>
    </select>
</td>
<td><input disabled class="form-control form-control-plaintext" name="price" id="price-<?php echo e($user->id); ?>" type="text"
        value="<?php echo e($user->remember_token); ?>" readonly></td>
<td><a href="javacript:" onclick="Edituser(<?php echo e($user->id); ?>)" id="btnEdit-<?php echo e($user->id); ?>"><span
            class="ion ion-md-build"></span></a>
    <a href="javacript:" hidden onclick="SaveEdituser(<?php echo e($user->id); ?>)" id="btnSave-<?php echo e($user->id); ?>"><span
            class="ion ion-md-save"></span></a></td>
<td><a href="admin/user/delete/<?php echo e($user->id); ?>"><span class="ion ion-md-trash"></span></a></td>
<?php /**PATH E:\xampp\htdocs\WebBanHangLaravel\WebBanDoAn\resources\views/admin/user/add.blade.php ENDPATH**/ ?>