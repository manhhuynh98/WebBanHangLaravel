<?php $__env->startSection('title'); ?>
List User
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-page">
    <div class="content">

        <!-- Start Content-->
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <h4 class="page-title pt-2">List User</h4>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-centered mb-0 table-nowrap" id="table">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody id="testid">
                                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr id="edit-<?php echo e($item->id); ?>">
                                            <td><input disabled class="form-control form-control-plaintext" name="name" id="name-<?php echo e($item->id); ?>" type="text" value="<?php echo e($item->name); ?>"></td>
                                            <td><input disabled class="form-control form-control-plaintext" name="email" id="email-<?php echo e($item->id); ?>" type="text" value="<?php echo e($item->email); ?>"></td>
                                            <td><a href="admin/role/add/<?php echo e($item->id); ?>"><span class="ion ion-md-build mr-4"></span></a>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- end .table-responsive-->
                        </div>
                        <!-- end card-body -->
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->
            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\WebBanHangLaravel\WebBanDoAn\resources\views/admin/user/role.blade.php ENDPATH**/ ?>