<?php $__env->startSection('content'); ?>
<div class="content-page">
    <div class="content">

        <!-- Start Content-->
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <h4 class="page-title pt-2">List Category</h4>
                        <a href="javacript:" id="addItem"><span class="ion ion-md-add font-44 pl-3 float-right"></span></a>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-centered mb-0 table-nowrap" id="table">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th>Name</th>
                                            <th>Image</th>
                                            <th>Created_at</th>
                                            <th>Updated_at</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr  id="edit-<?php echo e($item->id); ?>">
                                                <td><input disabled class="form-control form-control-plaintext"  name="name" id="name-<?php echo e($item->id); ?>" type="text" value="<?php echo e($item->name); ?>"></td>
                                                <td><input disabled class="form-control form-control-plaintext" name="image" id="image-<?php echo e($item->id); ?>" type="text" value="<?php echo e($item->image); ?>"></td>
                                                <td><input disabled class="form-control form-control-plaintext" name="created_at" id="created_at-<?php echo e($item->id); ?>" type="text" value="<?php echo e($item->created_at); ?>"></td>
                                                <td><input disabled class="form-control form-control-plaintext" name="updated_at" id="updated_at-<?php echo e($item->id); ?>" type="text" value="<?php echo e($item->updated_at); ?>"></td>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', 'App\Category')): ?>
                                                <td><a href="javacript:" onclick="EditItem(<?php echo e($item->id); ?>)" id="btnEdit-<?php echo e($item->id); ?>" ><span class="ion ion-md-build mr-4"></span></a>
                                                    <a href="javacript:" hidden onclick="SaveEditItem(<?php echo e($item->id); ?>)" id="btnSave-<?php echo e($item->id); ?>" ><span class="ion ion-md-save mr-4"></span></a>
                                                    <a href="javacript:" hidden onclick="CancelEditItem(<?php echo e($item->id); ?>)" id="btnCancel-<?php echo e($item->id); ?>"><span class="ion ion-md-close"></span></a>
                                                <?php endif; ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', 'App\Category')): ?>
                                                <a href="admin/category/delete/<?php echo e($item->id); ?>" id="btnDelete-<?php echo e($item->id); ?>"><span class="ion ion-md-trash"></span></a></td>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- end .table-responsive-->
                        </div>
                        <!-- end card-body -->
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->
            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    function EditItem(id){
        $('#btnEdit-'+id).attr('hidden','');
        $('#btnDelete-'+id).attr('hidden','');
        $('#btnSave-'+id).removeAttr('hidden');
        $('#btnCancel-'+id).removeAttr('hidden');
        $('#name-'+id).removeAttr('disabled');
        $('#image-'+id).removeAttr('disabled');
        $('#created_at-'+id).removeAttr('disabled');
        $('#updated_at-'+id).removeAttr('disabled');
    }

    function CancelEditItem(id){
        $('#btnEdit-'+id).removeAttr('hidden');
        $('#btnDelete-'+id).removeAttr('hidden');
        $('#btnSave-'+id).attr('hidden','');
        $('#btnCancel-'+id).attr('hidden','');
        $('#name-'+id).attr('disabled','');
        $('#image-'+id).attr('disabled','');
        $('#created_at-'+id).attr('disabled','');
        $('#updated_at-'+id).attr('disabled','');

        $.ajax({
            type: "GET",
            url: "admin/category/edit/"+id,
            success: function (response) {
                $('#edit-'+id).empty;
                $('#edit-'+id).html(response);
            }
        });
    }

    function SaveEditItem(id) {
        name = $('#name-'+id).val();
        image= $('#image-'+id).val();
        created_at= $('#created_at-'+id).val();
        updated_at= $('#updated_at-'+id).val();

        $.ajax({
            type: "POST",
            url: "admin/category/edit/"+id,
            data: {
                name: name,
                image: image,
                created_at: created_at,
                updated_at: updated_at,
                _token: '<?php echo e(csrf_token()); ?>',
            },
            success: function (response) {
                $('#edit-'+id).empty;
                $('#edit-'+id).html(response);
                alert('ok');
            }
        });
    }

    $('#addItem').click(function () {
        $('table tbody').append('<tr id="add"> <td><input class="form-control form-control-plaintext" name="name" id="name" type="text" value="" placeholder="Hãy nhập thông tin" ></td> <td><input  class="form-control form-control-plaintext" name="image" id="image" type="text" value="" placeholder="Hãy nhập thông tin"></td> <td><input  class="form-control form-control-plaintext" name="created_at" id="created_at" type="text" value="" placeholder="Hãy nhập thông tin"></td> <td><input  class="form-control form-control-plaintext" name="updated_at" id="updated_at" type="text" value="" placeholder="Hãy nhập thông tin"></td> <td><a href="javacript:" onclick="btnSave()" id="btnSave"><span class="ion ion-md-save mr-4"></span></a><a href="javascipt:" onclick="btnCancel()"><span class="ion ion-md-close"></span></a></td> </tr>');
        $('#addItem').attr('hidden',"");
    })

    function btnSave(){
        name = $('#name').val();
        image = $('#image').val();
        created_at = $('#created_at').val();
        updated_at = $('#updated_at').val();

        $.ajax({
            type: "POST",
            url: "admin/category/add",
            data: {
                name: name,
                image: image,
                created_at: created_at,
                updated_at: updated_at,
                _token: '<?php echo e(csrf_token()); ?>',
            },
            success: function (response) {
                $('#add').empty;
                $('#add').html(response);
                $('#addItem').removeAttr('hidden');
                alert('ok');
            }
        });
    }

    function btnCancel() {
        $( "tr" ).remove( "#add" );
        $('#addItem').removeAttr('hidden');
    }


</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\WebBanHangLaravel\WebBanDoAn\resources\views/admin/category/list.blade.php ENDPATH**/ ?>