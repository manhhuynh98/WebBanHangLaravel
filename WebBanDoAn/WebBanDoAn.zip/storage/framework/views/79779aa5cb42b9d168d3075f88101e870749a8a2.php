<?php $__env->startSection('title'); ?>
Home
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Latest Products Start -->
<section class="latest-product-area padding-bottom">
    <div class="container" id="resultsearch">
        <div class="row product-btn d-flex align-items-end">
            <!-- Section Tittle -->
            <div class="col-xl-4 col-lg-5 col-md-5">
                <div class="section-tittle mb-30">
                    <h2>Hot Products</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-3 col-lg-3 col-md-4">
                    <div class="single-product mb-60">
                        <div class="product-img">
                            <a href="product-detail/<?php echo e($item->id); ?>">
                                <img src="<?php echo e($item->image); ?>" alt="">
                            </a>
                            <div class="new-product">
                                <span>New</span>
                            </div>
                        </div>
                        <div class="product-caption">
                            <h4><a href="product-detail/<?php echo e($item->id); ?>"><?php echo e($item->name); ?></a></h4>
                            <div class="price">
                                <ul>
                                    <li style="color: #ee4d2d"><span>₫ </span><?php echo e(number_format($item->price)); ?></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <div class="pagination justify-content-end">
            <?php echo e($product->links()); ?>

        </div>

        <div class="row product-btn d-flex align-items-end">
            <!-- Section Tittle -->
            <div class="col-xl-4 col-lg-5 col-md-5">
                <div class="section-tittle mb-30">
                    <h2>Latest Products</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-3 col-lg-3 col-md-4">
                    <div class="single-product mb-60">
                        <div class="product-img">
                            <img src="<?php echo e($item->image); ?>" alt="">
                            <div class="new-product">
                                <span>Hot</span>
                            </div>
                        </div>
                        <div class="product-caption">
                            <h4><a href="product-detail/<?php echo e($item->id); ?>"><?php echo e($item->name); ?></a></h4>
                            <div class="price">
                                <ul>
                                    <li style="color: #ee4d2d"><span>₫ </span><?php echo e(number_format($item->price)); ?></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="pagination justify-content-end">
            <?php echo e($product->links()); ?>

        </div>
    </div>
</section>
<!-- Latest Products End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\WebBanHangLaravel\WebBanDoAn\resources\views/pages/home.blade.php ENDPATH**/ ?>