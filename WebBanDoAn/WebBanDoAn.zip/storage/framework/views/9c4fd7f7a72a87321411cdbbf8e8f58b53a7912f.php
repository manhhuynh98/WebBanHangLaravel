
<td><input disabled class="form-control form-control-plaintext" name="name" id="name-<?php echo e($category->id); ?>" type="text" value="<?php echo e($category->name); ?>"></td>
<td><input disabled class="form-control form-control-plaintext" name="image" id="image-<?php echo e($category->id); ?>" type="text" value="<?php echo e($category->image); ?>"></td>
<td><input disabled class="form-control form-control-plaintext" name="created_at" id="created_at-<?php echo e($category->id); ?>" type="text" value="<?php echo e($category->created_at); ?>"></td>
<td><input disabled class="form-control form-control-plaintext" name="updated_at" id="updated_at-<?php echo e($category->id); ?>" type="text" value="<?php echo e($category->updated_at); ?>"></td>
<td><a href="javacript:" onclick="EditItem(<?php echo e($category->id); ?>)" id="btnEdit-<?php echo e($category->id); ?>"><span class="ion ion-md-build"></span></a>
    <a href="javacript:" onclick="SaveEditItem(<?php echo e($category->id); ?>)" hidden id="btnSave-<?php echo e($category->id); ?>"><span class="ion ion-md-save"></span></a></td>
<td><a href="admin/category/delete/<?php echo e($category->id); ?>"><span class="ion ion-md-trash"></span></a></td>
<?php /**PATH E:\xampp\htdocs\WebBanHangLaravel\WebBanDoAn\resources\views/admin/category/add.blade.php ENDPATH**/ ?>