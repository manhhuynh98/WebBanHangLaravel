<td><input disabled class="form-control form-control-plaintext"  name="name" id="name-<?php echo e($product->id); ?>" type="text" value="<?php echo e($product->name); ?>"></td>
<td><input disabled class="form-control form-control-plaintext" name="image" id="image-<?php echo e($product->id); ?>" type="text" value="<?php echo e($product->image); ?>"></td>
<td><input disabled class="form-control form-control-plaintext" name="content" id="content-<?php echo e($product->id); ?>" type="text" value="<?php echo e($product->content); ?>"></td>
<td><input disabled class="form-control form-control-plaintext" name="p-price" id="p-price-<?php echo e($product->id); ?>"
    type="text" value="<?php echo e(number_format($product->purchase_price)); ?>"></td>
<td><input disabled class="form-control form-control-plaintext" name="s-price" id="s-price-<?php echo e($product->id); ?>"
    type="text" value="<?php echo e(number_format($product->sale_price)); ?>"></td>
<td><select name="idCategory" id="idCategory-<?php echo e($product->id); ?>" class="form-control form-control-plaintext">
    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($cat->id == $product->idCategory): ?>
            <option value="<?php echo e($cat->id); ?>" selected ><?php echo e($cat->name); ?></option>
        <?php else: ?>
            <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select></td>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', 'App\Product')): ?>
<td><a href="javacript:" onclick="EditItem(<?php echo e($product->id); ?>)" id="btnEdit-<?php echo e($product->id); ?>"><span
            class="ion ion-md-build mr-4"></span></a>
    <a href="javacript:" hidden onclick="SaveEditItem(<?php echo e($product->id); ?>)" id="btnSave-<?php echo e($product->id); ?>"><span
            class="ion ion-md-save mr-4"></span></a>
    <a href="javacript:" hidden onclick="CancelEditItem(<?php echo e($product->id); ?>)" id="btnCancel-<?php echo e($product->id); ?>"><span
            class="ion ion-md-close"></span></a>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', 'App\Product')): ?>
    <a href="admin/user/delete/<?php echo e($product->id); ?>" id="btnDelete-<?php echo e($product->id); ?>"><span
            class="ion ion-md-trash"></span></a></td>
<?php endif; ?>

<?php /**PATH E:\xampp\htdocs\WebBanHangLaravel\WebBanDoAn\resources\views/admin/product/add.blade.php ENDPATH**/ ?>