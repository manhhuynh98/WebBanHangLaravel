<td><input disabled class="form-control form-control-plaintext" name="name" id="name-<?php echo e($user->id); ?>" type="text"
        value="<?php echo e($user->name); ?>"></td>
<td><input disabled class="form-control form-control-plaintext" name="email" id="email-<?php echo e($user->id); ?>" type="text"
        value="<?php echo e($user->email); ?>"></td>
<td><input disabled class="form-control form-control-plaintext" name="image" id="image-<?php echo e($user->id); ?>" type="text"
        value="<?php echo e($user->image); ?>"></td>
<td><input disabled class="form-control form-control-plaintext" name="price" id="price-<?php echo e($user->id); ?>" type="text"
        value="<?php echo e($user->remember_token); ?>" readonly></td>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', 'App\User')): ?>
<td><a href="javacript:" onclick="EditItem(<?php echo e($user->id); ?>)" id="btnEdit-<?php echo e($user->id); ?>"><span
            class="ion ion-md-build mr-4"></span></a>
    <a href="javacript:" hidden onclick="SaveEditItem(<?php echo e($user->id); ?>)" id="btnSave-<?php echo e($user->id); ?>"><span
            class="ion ion-md-save mr-4"></span></a>
    <a href="javacript:" hidden onclick="CancelEditItem(<?php echo e($user->id); ?>)" id="btnCancel-<?php echo e($user->id); ?>"><span
            class="ion ion-md-close"></span></a>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', 'App\User')): ?>
    <a href="admin/user/delete/<?php echo e($user->id); ?>" id="btnDelete-<?php echo e($user->id); ?>"><span
            class="ion ion-md-trash"></span></a></td>
<?php endif; ?>
<?php /**PATH E:\xampp\htdocs\WebBanHangLaravel\WebBanDoAn\resources\views/admin/user/edit.blade.php ENDPATH**/ ?>