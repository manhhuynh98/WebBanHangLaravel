<?php $__env->startSection('title'); ?>
List User
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-page">
    <div class="content">
        <div class="row justify-content-center mt-5">
            <div class="col-md-11">
                <form method="POST" action="admin/role/add/<?php echo e($user->id); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group mx-4">
                        <input disabled class="form-control form-control-plaintext" value="<?php echo e($user->name); ?>">
                    </div>
                    <div class="form-group mx-4">
                      <input disabled class="form-control form-control-plaintext" value="<?php echo e($user->email); ?>">
                    </div>
                    <div class="row mb-4 ml-4">
                        <div class="col-3 mt-3 form-check-inline ">
                            <input type="checkbox" value="" class="form-check-input ml-5" id="selectAll">
                            <label class="form-check-label" >select all</label>
                        </div>
                        <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-3 mt-3 form-check-inline ">
                            <input type="checkbox" value="<?php echo e($item->id); ?>" class="form-check-input ml-5 checkRole" name="role[]"
                            <?php echo e($roleOfUser->contains($item->id) ? 'checked' : ''); ?>

                            >
                            <label class="form-check-label"><?php echo e($item->display_name); ?></label>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="row justify-content-end mr-4">
                        <button type="submit" class="btn btn-primary">Submit</button>

                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
        $('#selectAll').change(function () {
            if($(this).is(':checked')){
                console.log(1);
                $('.checkRole').attr('checked','');
            }else{
                $('.checkRole').removeAttr('checked')
            }
        })
        console.log(3);
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\WebBanHangLaravel\WebBanDoAn\resources\views/admin/user/addrole.blade.php ENDPATH**/ ?>