
<td><input disabled class="form-control form-control-plaintext" name="name" id="name-<?php echo e($category->id); ?>" type="text" value="<?php echo e($category->name); ?>"></td>
<td><input disabled class="form-control form-control-plaintext" name="image" id="image-<?php echo e($category->id); ?>" type="text" value="<?php echo e($category->image); ?>"></td>
<td><input disabled class="form-control form-control-plaintext" name="created_at" id="created_at-<?php echo e($category->id); ?>" type="text" value="<?php echo e($category->created_at); ?>"></td>
<td><input disabled class="form-control form-control-plaintext" name="updated_at" id="updated_at-<?php echo e($category->id); ?>" type="text" value="<?php echo e($category->updated_at); ?>"></td>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', 'App\Category')): ?>
    <td><a href="javacript:" onclick="EditItem(<?php echo e($category->id); ?>)" id="btnEdit-<?php echo e($category->id); ?>" ><span class="ion ion-md-build mr-4"></span></a>
        <a href="javacript:" hidden onclick="SaveEditItem(<?php echo e($category->id); ?>)" id="btnSave-<?php echo e($category->id); ?>" ><span class="ion ion-md-save mr-4"></span></a>
        <a href="javacript:" hidden onclick="CancelEditItem(<?php echo e($category->id); ?>)" id="btnCancel-<?php echo e($category->id); ?>"><span class="ion ion-md-close"></span></a>
<?php endif; ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', 'App\Category')): ?>
    <a href="admin/category/delete/<?php echo e($category->id); ?>" id="btnDelete-<?php echo e($category->id); ?>"><span class="ion ion-md-trash"></span></a></td>
<?php endif; ?>

<?php /**PATH E:\xampp\htdocs\WebBanHangLaravel\WebBanDoAn\resources\views/admin/category/edit.blade.php ENDPATH**/ ?>